# ETC5510-Project

A report on the coronavirus pandemic. We conducted analysis on COVID-19 by focusing on 5 major sectors of the world. 

Please be informed that we were unable to get a HTML output because of the runtime:shiny component in our YAML. This component removed the "Knit"" option on our Rmd and replaced it with a "Run Document" button. You will be able to view an interactive document of our report once you click on the "Run Document". 

We hope you find our report informative!