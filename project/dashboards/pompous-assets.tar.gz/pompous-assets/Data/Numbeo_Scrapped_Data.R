library(polite)
library(rvest)
library(dplyr)
library(readr)

numbeo <- bow("https://www.numbeo.com/quality-of-life/rankings_by_country.jsp")

numbeo_data <- scrape(numbeo)

country <- numbeo_data %>% html_nodes(".cityOrCountryInIndicesTable") %>% html_text()

safety_index <- numbeo_data %>% html_nodes("td:nth-child(5)") %>% html_text() %>% parse_number()

quality_life <- numbeo_data %>% html_nodes("td:nth-child(3)") %>% html_text() %>% parse_number()

purchasing_power <- numbeo_data %>% html_nodes("td:nth-child(4)") %>% html_text() %>% parse_number()

health_care <- numbeo_data %>% html_nodes("td:nth-child(6)") %>% html_text() %>% parse_number()

cost_of_living <- numbeo_data %>% html_nodes("td:nth-child(7)") %>% html_text() %>% parse_number()

property_price_to_income_ratio <- numbeo_data %>% html_nodes("td:nth-child(8)") %>% html_text() %>% parse_number()

traffic_commute <- numbeo_data %>% html_nodes("td:nth-child(9)") %>% html_text() %>% parse_number()

pollution <- numbeo_data %>% html_nodes("td:nth-child(10)") %>% html_text() %>% parse_number()

climate <- numbeo_data %>% html_nodes("td:nth-child(11)") %>% html_text() %>% parse_number()

numbeo_tibble <- tibble(country = country,
                        quality_of_life_index = quality_life,
                        purchasing_power_index = purchasing_power,
                        safety_index = safety_index,
                        health_care_index = health_care,
                        cost_of_living_index = cost_of_living,
                        property_price_to_income_ratio = property_price_to_income_ratio,
                        traffic_commute_time_index = traffic_commute,
                        pollution_index = pollution,
                        climate_index = climate)
write.csv(numbeo_tibble, file = "quality_of_life.csv")


numbeo_2019 <- bow("https://www.numbeo.com/quality-of-life/rankings_by_country.jsp?title=2019")

numbeo_data_2019 <- scrape(numbeo_2019)

country <- numbeo_data_2019 %>% html_nodes(".cityOrCountryInIndicesTable") %>% html_text()

safety_index <- numbeo_data_2019 %>% html_nodes("td:nth-child(5)") %>% html_text() %>% parse_number()

quality_life <- numbeo_data_2019 %>% html_nodes("td:nth-child(3)") %>% html_text() %>% parse_number()

purchasing_power <- numbeo_data_2019 %>% html_nodes("td:nth-child(4)") %>% html_text() %>% parse_number()

health_care <- numbeo_data_2019 %>% html_nodes("td:nth-child(6)") %>% html_text() %>% parse_number()

cost_of_living <- numbeo_data_2019 %>% html_nodes("td:nth-child(7)") %>% html_text() %>% parse_number()

property_price_to_income_ratio <- numbeo_data_2019 %>% html_nodes("td:nth-child(8)") %>% html_text() %>% parse_number()

traffic_commute <- numbeo_data_2019 %>% html_nodes("td:nth-child(9)") %>% html_text() %>% parse_number()

pollution <- numbeo_data_2019 %>% html_nodes("td:nth-child(10)") %>% html_text() %>% parse_number()

climate <- numbeo_data_2019 %>% html_nodes("td:nth-child(11)") %>% html_text() %>% parse_number()

numbeo_tibble <- tibble(country = country,
                        quality_of_life_index = quality_life,
                        purchasing_power_index = purchasing_power,
                        safety_index = safety_index,
                        health_care_index = health_care,
                        cost_of_living_index = cost_of_living,
                        property_price_to_income_ratio = property_price_to_income_ratio,
                        traffic_commute_time_index = traffic_commute,
                        pollution_index = pollution,
                        climate_index = climate)
write.csv(numbeo_tibble, file = "quality_of_life_2019.csv")



