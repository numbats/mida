# ETC5510_FINALP

Step 1 : Run the full markdown from start in the console in order to create the extracted CSV's for the data scraping process.

Step 2 : Then set the eval = TRUE to eval = FALSE for all the chunks that currently have eval=TRUE

Step 3 : Run the Document for dashboard
