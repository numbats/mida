5510-project

Analysing Top 200 grossing movies in the past 25 Years

Through this project we will try and analyse the top 200 movies that made the most money in the past 25 years. The data for the same has been scraped from https://www.the-numbers.com/movie/budgets/all/101 for the list of the top 200 grossing movies. Then we created a function to extract the information of the cast and the directors which are available in the embedded link . We also extracted the information about the genre of the movie as that will allow us to draw further insights like which genres make the most money. The data also consists of the budget at which the movie was made which will help us understand what was the percentage of profit a movie made. This in turn will help us to compare the businesses done by various movies as percentage is a relative value of measure. 

Project Plans :

We will be exploring various aspects from this dataset. Like already mentioned the profit percentages for a start, we will also be doing network analysis for the directors and the cast to find out if a particular actor or director is involved in more than one top grossing film and if a pattern exists! We will also try to see if any particular genre is more successful than others and how many top grossing films fall in a similar genre.  We will also be making the visualisations user interactive by allowing them to enter a year and profit percentage to see if which films made what profits in a particular year.