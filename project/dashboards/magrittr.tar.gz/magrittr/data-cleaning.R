## ----setup, include=FALSE----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, eval = FALSE)
library(tidyverse)
library(polite)
library(rvest)
library(stringr)


## ----read and scrape---------------------------------------------------------
# rank 1-100 movies link
url1_100 <- ("https://www.the-numbers.com/movie/budgets/all")

# rank 101-200 movies link
url101_200 <- ("https://www.the-numbers.com/movie/budgets/all/101")


## ----title-------------------------------------------------------------------
url1_100 %>%
  bow() %>% scrape() %>%
  html_nodes(".data+ td a")%>%
  html_text() %>%
  # convert the date into Date format
  as.Date(date1, format = ("%b %d, %Y"))


## ----tibble function---------------------------------------------------------
scrape_movie_info <- function(url){
  scraped_movie <- url %>%
    bow() %>% scrape()
  
  date <- scraped_movie %>%
    html_nodes(".data+ td a")%>%
    html_text() %>%
    as.Date(date1, format = ("%b %d, %Y"))
  # Scrape title
  title <- scraped_movie %>%
    html_nodes("td:nth-child(3)")%>%
    html_text()
  # Scrape budget
  budget <- scraped_movie %>%
    html_nodes(".data:nth-child(4)") %>%
    html_text()
  # Scrape domestic gross
  domestic_gross <- scraped_movie %>%
    html_nodes(".data:nth-child(5)") %>%
    html_text()
  # Scrape worldwide gross
  worldwide_gross <- scraped_movie %>%
    html_nodes(".data:nth-child(6)") %>%
    html_text()
  # Create table
  tibble(date, title, budget, domestic_gross, worldwide_gross) # length is 200
}


## ----table of top 200 movies-------------------------------------------------
# movie ranking 1-100
tibble1 <- url1_100 %>%
  scrape_movie_info()

# movie ranking 101-200
tibble2 <- url101_200 %>%
  scrape_movie_info()

tibble1_200 <-bind_rows(tibble1,tibble2) # normal displayed

# bind two tables 
tibble1_200 %>%
  # Extract numbers
  mutate_at(c("budget", "domestic_gross","worldwide_gross"), parse_number) %>% 
  write.csv("data/movie_top200.csv")


move_top200 <- read_csv("data/movie_top200.csv", 
    locale = locale(encoding = "ASCII")) %>%
  rename(rank = X1)


## ----------------------------------------------------------------------------
# create links in the second half of the address

html_1_100 <- read_html(url1_100) %>% # this is the movie from rank 1 to 100
  html_nodes("td:nth-child(3) a") %>%
  html_attr('href') %>%
  paste0("https://www.the-numbers.com", .)

html_101_200 <- read_html(url101_200) %>% # this is the movie from rank 101 to 200
  html_nodes("td:nth-child(3) a") %>%
  html_attr('href') %>%
  paste0("https://www.the-numbers.com", .)


## ----individual movie--------------------------------------------------------
# the link is Avenger-Endgame movie
url_movie <- ("https://www.the-numbers.com/movie/Avengers-Endgame-(2019)#tab=cast-and-crew")


## ----summary-title-----------------------------------------------------------
# scrape movie title from summary
movie_title <- ("https://www.the-numbers.com/movie/Avengers-Age-of-Ultron#tab=summary") %>%
  bow() %>% scrape() %>%
  html_nodes("#main h1") %>%
  html_text()

movie_title <-movie_title[1] 


movie_title %>%
  # remove last 7 digits
  str_sub(end = -8)
  


## ----casts-------------------------------------------------------------------
# lead casts, from casts and crew
url_movie %>%
  bow() %>% scrape() %>%
  html_nodes(".cast_new:nth-child(1) span") %>%
  html_text() %>%
  list()


## ----directors---------------------------------------------------------------
# directors of the movie, from casts and crew
director <- url_movie %>%
  bow() %>% scrape() %>%
  html_nodes(".inactive , p+ .cast_new span") %>%
  html_text() %>%
  as.tibble()

director


## ----genre-------------------------------------------------------------------
# genre of the movie
# url of movie summary
("https://www.the-numbers.com/movie/Avengers-Age-of-Ultron#tab=summary") %>%
  bow() %>% scrape() %>%
  html_nodes("tr:nth-child(11) td+ td a") %>%
  html_text()


## ----function of summary-table-----------------------------------------------
# scrape data from =summary links
summary_tibble <- function(summary_url){ # This is website of movie summary

  summaryscrape <- summary_url %>%
    bow() %>% scrape()
  # Scrape movie information from summary tab
  movie_info <- summaryscrape %>%
    html_nodes("td a")%>%
    html_attr("href") %>%
    as_tibble()
  # select genre in the list of information in summary tab
  coln <- movie_info$value %>%
    str_detect("/market/genre") %>%
    which()
  # Extract genre
  clean_genre <- str_sub(movie_info$value[coln],15)
  
  return(clean_genre) # length is 200
}


## ----------------------------------------------------------------------------
# test the function above
  summary_tibble("https://www.the-numbers.com/movie/Tenet-(2020)#tab=summary")



## ----------------------------------------------------------------------------
genre_1_100 <-map_chr(html_1_100, summary_tibble)
genre_101_200 <- map_chr(html_101_200, summary_tibble)
genre_1_200 <- c(genre_1_100, genre_101_200)


## ----------------------------------------------------------------------------
# convert the vector to tibble, prepare for scrape cast and directors
html_1_100_cast <- html_1_100 %>% # This is the link for cast-and-crew tab (rank 1-100)
  str_replace("=summary", "=cast-and-crew") %>%
  as.tibble()

html_101_200_cast <- html_101_200 %>% # for rank 101-200 
  str_replace("=summary", "=cast-and-crew") %>%
  as.tibble()


## ----cast and crew-----------------------------------------------------------
cast_and_crew <- function(url){ # 
  scrape_url <- url %>%
    bow() %>% scrape()
  # Scrape casts
  casts <- scrape_url %>%
    html_nodes(".cast_new:nth-child(1) span") %>%
    html_text() %>%
    list() 
  # Scrape directors
  directors <- scrape_url %>%
    html_nodes(".inactive , p+ .cast_new span") %>%
    html_text() %>%
    list()
  
  tibble(casts, directors) # length is 200
}


## ----create-fulltable, eval= FALSE-------------------------------------------
## # test the function above, be careful, this chunk would take more than 10 mins.
## cast_1_100 <- map_df(html_1_100_cast[[1]][c(1:100)], cast_and_crew)
## cast_101_200 <- map_df(html_101_200_cast[[1]][c(1:100)], cast_and_crew)
## movie_1_200 <- bind_rows(cast_1_100,cast_101_200) %>%
##   bind_cols(move_top200, .)
## 
## 


## ----write-csv-file, eval= FALSE---------------------------------------------
## movie_1_200 %>%
##   mutate(genre = genre_1_200) %>%
##   # mutate_at(c("budget", "domestic_gross","worldwide_gross"), parse_number) %>% # This step is already taken in previous chunk
##   # unnest(casts)%>%
##   # unnest(directors)%>%
##   saveRDS("data/movie_top_200_full.rds", ascii =TRUE)


## ----------------------------------------------------------------------------
movie_top200 <- read_rds("data/movie_top_200_full.rds")


