5510-project

Analysing Top 200 grossing movies in the past 25 Years

Through this project we will try and analyse the top 200 movies that made the most money in the past 25 years. The data for the same has been scraped from https://www.the-numbers.com/movie/budgets/all/101 for the list of the top 200 grossing movies. Then we created a function to extract the information of the cast and the directors which are available in the embedded link . We also extracted the information about the genre of the movie as that will allow us to draw further insights like which genres make the most money. The data also consists of the budget at which the movie was made which will help us understand what was the percentage of profit a movie made. This in turn will help us to compare the businesses done by various movies as percentage is a relative value of measure. 

Project Plans :

We will be exploring various aspects from this dataset. Like already mentioned the profit percentages for a start, we will also be doing network analysis for the directors and the cast to find out if a particular actor or director is involved in more than one top grossing film and if a pattern exists! We will also try to see if any particular genre is more successful than others and how many top grossing films fall in a similar genre.  We will also be making the visualisations user interactive by allowing them to enter a year and profit percentage to see if which films made what profits in a particular year.

###Analysing the top grossing movie data from 1995-2020.

Through this project, we will analyse various aspects of the top 200 top grossing movies in the past 25 years and answer some questions like :

- Are the top grossing movies actually profitable?
- Do the top grossing movies perform better internationally or domestically?
- Are there any genres that make more money than others?
- Use network analysis to figure out if the services of a director or a cast member is more profitable to employ.
- create a linear model to check if the wordwide gross is related to the genre or the cast and crew.

###About the data :

- The data for this project has been scrapped from https://www.the-numbers.com/movie/budgets/all/101 for the table of the top 200 grossing films which contained the variables rank, date, title, budget, domestic_gross, worldwide_gross.

- Then we used string manipulation techniques to remove ',' and $ signs and also changed the format of the date using the lubridate package.

- Then we created functions to extract additional information about the movies like cast,directors and genre which were available in the embedded links and attached them to the main dataset.

- During the analysis we created more columns out of the scraped dataset like profit and international gross to draw insights and visualisations.

###About plot 1 with 2 visualisations.

Here, we have used user input to display 2 plots using the same inputs. The user has the choice to input a range of dates and slect the genre of the movies and plot-1 depicts the budget and the profit that movies made in that time frame and are displayed using a bar chart. Plot-2 depicts the colllection the movies made in that time frame domestically as well as internationally. We have calculated international gross by subtracting domestic gross from the worlwide gross. Important to notice that in both the plots the bars are overlapping which is why we have used different colours to depict the attributes.

###About the plotly plot

Then we have created an interactive scatter plot using the plotly library. This plot depicts all the 200 movies on a scatter plot with the y-axis representing the worldwide gross that the movies made and the x-axis represents the year. Each movie is potrayed by a different colour.

###About the genre table

Then we created a table to check amongst the top 200 grossing movies of all times, if a particular genre is overpowering other genres between all the movies. In the table, we have summarised all the movies in a genre to calculate the total worldwide gross a genre has made and how many movies were made in that genre. It is evident from the table that the most number of movies were made in the adventure genre, however the action genre has made the most money by a fair distance. The rest of the genres have only a few movies to show in the top 200 grossing movies of all time.

###About genre boxplot

Then we used this data to create a boxplot for all the genres with the x-axis representing the genres and y-axis representing the budget at which the movies were made. The boxplot depicts that the budget required to make a action movie is more than any other genre. This can be because of the reason that action movies require a big investment on Visual Effects (VFX) and exotic shooting locations. Outliers are also most visible in the genre of action and adventure.
