#Group Forcats
#Group member: Jinghan Zhang, Vinny Vu, Yanyi Wan

# read library
library(shiny)
library(shinydashboard)
library(tidyverse)
library(readr)
library(readxl)
library(here)
library(broom)
library(plotly)
library(tidyr)
library(sf)
#library(absmapsdata) # remotes::install_github("wfmackey/absmapsdata")
library(shinyWidgets)
library(plotly)
library(ggplot2)
library(ggmap)# load ggmap
#library(rmapshaper)




#Read Data
income_age_sex <- read_csv('income.csv')
crime_house_income <- read_csv('income_crime_house_final.csv')
LGA_data <- read_csv('LGA_Data.csv')
crime_house <- read_csv('crime_house.csv')

house_2016_top15 <- crime_house_income %>%
  arrange(desc(`2016_price`)) %>%
  head(15)
house_2016_bottom15 <- crime_house_income %>%
  arrange(`2016_price`) %>%
  head(15)

Incident_rate_bottom15 <- crime_house_income %>%
  arrange(`Incidents_rate`) %>%
  head(15)

Incident_rate_top15 <- crime_house_income %>%
  arrange(desc(`Incidents_rate`)) %>%
  head(15)

Income_Top15 <- crime_house_income %>%
  arrange(desc(`mean_income`)) %>%
  head(15)

crime_house_top10 <- crime_house %>% 
  group_by(LGA) %>%
  summarise(Incidents = sum(Incidents)) %>%
  ungroup() %>% 
  arrange(desc(Incidents)) %>%
  head(10)

crime_house_bot10 <- crime_house %>% 
  group_by(LGA) %>%
  summarise(Incidents = sum(Incidents)) %>%
  ungroup() %>% 
  arrange(Incidents) %>%
  head(10)

# read map data
#mapdata1 <- sa32016
#simplified_mapdata1 <- rmapshaper::ms_simplify(mapdata1)
simplified_mapdata1 <- read_rds("map.rds")

combined_data_1 <- left_join(simplified_mapdata1, crime_house_income, by = c("sa3_name_2016" = 'LGA'))

# Define UI for application that draws a histogram
ui <- dashboardPage(
  dashboardHeader(title = 'ETC5510-Project'),
  dashboardSidebar(
    sidebarMenu(
      menuItem('Project Description', tabName = 'dashboard1'),
      menuSubItem('Data Wrangling', tabName = 'dashboard1_1'),
      menuSubItem('Data Source', tabName = 'dashboard1_2'),
      menuItem('Project Overview', tabName = 'dashboard2'),
      menuItem('Map Information', tabName = 'dashboard3'),
      menuItem('linear Regression',tabName = 'dashboard4'),
      menuItem('Reference', tabName = 'dashboard5')
    ),uiOutput('style_tag')),
  dashboardBody(
    tabItems(
      tabItem(tabName = 'dashboard1',
              fluidPage(setBackgroundColor("ghostwhite"),
                        mainPanel(tags$img(src = '1234.png',height="130%", width="130%"),
                                  tags$img(src = 'Picture1.png',height="130%", width="130%")))),
      tabItem(tabName = 'dashboard1_1',
              fluidPage(setBackgroundColor("ghostwhite"),
                        mainPanel(tags$img(src = '2.1.png',height="130%", width="130%"),
                                  tags$img(src = '2.2.png',height="130%", width="130%"),
                                  tags$img(src = '2.31.png',height="130%", width="130%"),
                                  tags$img(src = '2.4.png',height="130%", width="130%"),
                                  tags$img(src = '2.6.png',height="130%", width="130%"),
                                  tags$img(src = '2.7.png',height="130%", width="130%"),))),
      tabItem(tabName = 'dashboard1_2', 
              h3('Here are some links where you can find the dataset'),
              h5('(If the link expried, please go to the ABS.gov.au to find the data)'),
              fluidPage(mainPanel(tags$a(href="https://www.abs.gov.au/AUSSTATS/abs@.nsf/DetailsPage/6524.0.55.0022011-12%20to%202016-17?OpenDocument", "Victoria employee income data")),
                        
                        mainPanel(tags$a(href="https://www.abs.gov.au/AUSSTATS/abs@.nsf/DetailsPage/6524.0.55.0022011-12%20to%202016-17?OpenDocument", "Employee income by Age and Sex")),
                        mainPanel(tags$a(href="https://www.crimestatistics.vic.gov.au/crime-statistics/latest-crime-data/download-data", "Crime Incidents data")),
                        mainPanel(tags$a(href="https://discover.data.vic.gov.au/dataset/victorian-property-sales-report-median-house-by-suburb", "House price data")),
                        mainPanel(tags$a(href="https://github.com/wfmackey/absmapsdata", "Map data"),)))
      ,
      
      tabItem(tabName = 'dashboard2',
              fluidPage(setBackgroundColor("ghostwhite"),
                        sidebarLayout(
                          sidebarPanel(
                            selectInput('y1','select the data',choices = c('Top_15_house_price', 'Bottom_15_house_price',
                                                                       'Incident_rate_bottom15',
                                                                       'Incident_rate_top15',
                                                                       'mean_income',
                                                                       'Residential Burglary Incidents top10',
                                                                       'Residential Burglary Incidents bot10'),selected = 'Top_15_house_price')
                          ),
                          mainPanel(plotlyOutput('bar', width = '100%'))
                          
                        )),
              fluidPage(
                titlePanel('Check the LGA & Suburb'),
                sidebarLayout(
                  sidebarPanel(
                    textInput('LGA_NAME', 'Enter the LGA name', '')
                  ),
                  mainPanel(tableOutput('LGA_table'))
                )
              ),
              fluidPage(mainPanel(tags$img(src = 'bar.png',height="130%", width="130%")))
              
      ),
      
      tabItem(tabName = 'dashboard3',
              fluidPage(
                mainPanel(plotlyOutput('map'), width = '100%')
              ),
              fluidPage(
                mainPanel(plotlyOutput('map2'), width = '100%')),
              fluidPage(
                sidebarLayout(
                  sidebarPanel(
                    selectInput('b1', 'select the data', choices = c('Age_group', 'Gender'),selected = 'Age_group')
                  ),
                  mainPanel(plotlyOutput('boxplot',width = '80%'))
                )
              ),
              fluidPage(mainPanel(tags$img(src = 'map.png',height="130%", width="130%"))))
      ,
      
      tabItem(tabName = 'dashboard4',
              fluidPage(
                sidebarLayout(
                  sidebarPanel(
                    selectInput('y2', 'select pairs', choices = c('Crime_rate VS House_price',
                                                                  'Incident_number VS House_price',
                                                                  'Income VS House_price',
                                                                  'Crime_rate VS Income'), selected = 'Crime_rate VS House_price')
                  ),
                  mainPanel(plotlyOutput('linear'),
                            verbatimTextOutput('stats'))
                  
                )
                
              ),
              fluidPage(mainPanel(tags$img(src = 'regression.png',height="130%", width="130%")))
      ),
      
      tabItem(tabName = 'dashboard5',
              fluidPage(
                mainPanel(tags$img(src = 'refe.png',height="130%", width="130%"),
                          tags$img(src = 'rpack.png',height="130%", width="130%"))
              )
        
      )
      
      
    )
  ))







# Define server logic required to draw a histogram
server <- function(input, output) {
  output$style_tag <- renderUI({
    tags$head(tags$style(HTML('.content-wrapper {background-color:white;}')))
  })
  output$bar <- renderPlotly({
    if (input$y1 == 'Incident_rate_bottom15'){
      ggplot(Incident_rate_bottom15, aes(x = reorder(Incident_rate_bottom15$LGA, -Incident_rate_bottom15$Incidents_rate),
                                         y = Incident_rate_bottom15$Incidents_rate)) +
        geom_col(fill='steelblue3') +
        labs(title = "Residential Burglary Incidents_rate to LGA - BOT15",
             x = "LGA",
             y = 'Incident_rate')+
        coord_flip()+
        theme(axis.text.x=element_text(angle = -30))
      
      
    }
    else if (input$y1 == 'Incident_rate_top15'){
      ggplot(Incident_rate_top15, aes(x = reorder(LGA, Incidents_rate),
                                         y = Incidents_rate)) +
        geom_col(fill='steelblue3') +
        labs(title = "Residential Burglary Incidents_rate to LGA - TOP15",
             x = "LGA",
             y = 'Incident_rate')+
        coord_flip()+
        theme(axis.text.x=element_text(angle = -30))
      
      
    }
    else if (input$y1 == 'Residential Burglary Incidents top10'){
      ggplot(crime_house_top10, aes(x = reorder(LGA, Incidents),
                 y = Incidents)) +
        geom_col(fill='steelblue3') +
        labs(title = "Residential Burglary Incidents to LGA - TOP10",
             x = "LGA")+
        coord_flip()+
        theme(axis.text.x=element_text(angle = -0))
    }
    else if (input$y1 == 'Residential Burglary Incidents bot10'){
      ggplot(crime_house_bot10, aes(x = reorder(LGA, -Incidents),
                                    y = Incidents)) +
        geom_col(fill='steelblue3') +
        labs(title = "Residential Burglary Incidents to LGA - BOT10",
             x = "LGA")+
        coord_flip()+
        theme(axis.text.x=element_text(angle = -0))
    }
    else if (input$y1 == 'mean_income'){
      ggplot(Income_Top15, aes(x = reorder(Income_Top15$LGA, Income_Top15$mean_income),
                                         y = Income_Top15$mean_income)) +
        geom_col(fill='steelblue3') +
        labs(title = "Mean of income Top15 LGA",
             x = "LGA",
             y = 'mean_income')+
        coord_flip()+
        theme(axis.text.x=element_text(angle = -30))
    }
    else if (input$y1 == 'Top_15_house_price'){
      ggplot(house_2016_top15, aes(x = reorder(house_2016_top15$LGA, house_2016_top15$`2016_price`),
                                   y = `2016_price`)) +
        geom_col(fill='steelblue3') +
        labs(title = "LGA to House Price - Top 15",
             x = "LGA",
             y = "2016 Median House Price") +
        coord_flip()+
        theme(axis.text.x=element_text(angle = -30))
      
    }
    else{
      ggplot(house_2016_bottom15, aes(x = reorder(house_2016_bottom15$LGA, -house_2016_bottom15$`2016_price`),
                                      y = `2016_price`)) +
        geom_col(fill='steelblue3') +
        labs(title = "LGA to House Price - Bottom 15",
             x = "LGA",
             y = "2016 Median House Price") +
        coord_flip()+
        theme(axis.text.x=element_text(angle = -30))
      
    }
  })
  
  output$LGA_table <- renderTable({
    LGAfilter <- subset(LGA_data, LGA_data$LGA == input$LGA_NAME)
  })
  
  output$linear <- renderPlotly({
    if (input$y2 == 'Crime_rate VS House_price'){
      ggplot(crime_house_income, aes(x = `2016_price`,
                                     y = `Incidents_rate`)) +
        geom_point()+
        labs(title = "2016 house price to residential burglary incident rate",
             x = "House Price 2016",
             y = 'Incidents_rate')+
        geom_smooth(method = "lm", se = FALSE)
    }
    else if (input$y2 == 'Income VS House_price'){
      ggplot(crime_house_income, aes(x = `2016_price`,
                                     y = `mean_income`)) +
        geom_point()+
        labs(title = "Income to house price",
             x = "Median House Price",
             y = 'Mean Income')+
        geom_smooth(method = "lm", se = FALSE)
    }
    else if (input$y2 == 'Incident_number VS House_price'){
      ggplot(crime_house, aes(x = Incidents, y = `2016_price`)) +
        geom_point()+
        labs(title = "2016 house price to residential burglary",
             x = "House Price 2016",
             y = 'Incident')+
        geom_smooth(method = "lm", se = FALSE)
    }
    else{
      ggplot(crime_house_income, aes(x = `Incidents_rate`,
                                     y = `mean_income`)) +
        geom_point()+
        labs(title = "Income to Crime rate",
             x = "Incidents_rate",
             y = 'Mean Income')+
        geom_smooth(method = "lm", se = FALSE)
    }
  })
  
  output$stats <- renderPrint({
    if (input$y2 == 'Income VS House_price'){
      income_house_rate_lm <-  
        lm( mean_income ~ `2016_price`, data = crime_house_income)
      glance(income_house_rate_lm) %>% knitr::kable()
    }
    else if (input$y2 == 'Incident_number VS House_price'){
      crime_house_lm <-  
        lm( Incidents ~ `2016_price`, data = crime_house)
      glance(crime_house_lm) %>% knitr::kable()
    }
    else if (input$y2 == 'Crime_rate VS House_price'){
      crime_house_rate_lm <-  
        lm( Incidents_rate ~ `2016_price`, data = crime_house_income)
      glance(crime_house_rate_lm) %>% knitr::kable()
    }
    else{
      income_crime_rate_lm <-  
        lm( Incidents_rate ~ `mean_income`, data = crime_house_income)
      glance(income_crime_rate_lm) %>% knitr::kable()
    }
  })
  
  output$map <- renderPlotly({
    combined_data_1 %>%
      filter(gcc_name_2016 == "Greater Melbourne") %>%   # let's just look Melbourne
      ggplot() +
      geom_sf(aes(geometry = geometry,  # use the geometry variable
                  fill = mean_income),        # fill by income
      ) +                
      theme_void() +                    # clears other plot elements
      coord_sf(crs = "+init=epsg:4326") +       # sets the coordinate reference system (to match Google Earth)       
      labs(fill = "Mean income")
  })
  
  output$map2 <- renderPlotly({
    combined_data_1 %>%
      filter(gcc_name_2016 == "Greater Melbourne") %>%   # let's just look Melbourne
      ggplot() +
      geom_sf(aes(geometry = geometry,  # use the geometry variable
                  fill = `2016_price`),        # fill by income
      ) +                
      theme_void() +                    # clears other plot elements
      coord_sf(crs = "+init=epsg:4326") +       # sets the coordinate reference system (to match Google Earth)       
      labs(fill = "median of house price")
  })
  
  output$boxplot <- renderPlotly({
    if (input$b1 == 'Age_group'){
      ggplot(income_age_sex, aes(x = age, y = mean_1617)) + 
        geom_boxplot(fill='steelblue3') +
        labs(title = "Income by age group",
             x = "Age group",
             y = "Mean income") +
        theme(axis.text.x=element_text(angle = 20))
      
    }
    else{
      ggplot(income_age_sex, aes(x = sex, y = mean_1617)) + 
        geom_boxplot(fill='steelblue3') +
        labs(title = "Income by Gender",
             x = "Gender",
             y = "Mean income") +
        theme(axis.text.x=element_text(angle = 20))
      
    }

  })
  
  output$ref <- renderText({
    
  }
  )
  
}


# Run the application 
shinyApp(ui = ui, server = server)
