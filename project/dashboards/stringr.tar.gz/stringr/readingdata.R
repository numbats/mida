library(tidyverse)
library(here)
library(lubridate)
library(readxl)
library(janitor)
library(visdat)
library(simputation)
library(naniar)
library(revgeo)

#storing all file names of the csv files to an object
tmin_files <- list.files(path = here::here("data", "tmin"), pattern = "*.csv", full.names = F)

#binding all csv files to one dataframe
tmin_raw <- map(here::here("data", "tmin", tmin_files), read_csv) %>% 
  bind_rows(.id = "file_name")

#cleaning the dataframe
tmin_clean <- tmin_raw %>% 
  fill(`site number`) %>% 
  fill(`site name`) %>% 
  filter(!is.na(date)) %>% 
  select(-"file_name") %>% 
  mutate(month = month(date)) %>% 
  mutate(year = year(date)) %>% 
  clean_names()


#storing all file names of the csv files to an object
tmax_files <- list.files(path = here::here("data", "tmax"), pattern = "*.csv", full.names = F)

#binding all csv files to one dataframe
tmax_raw <- map(here::here("data", "tmax", tmax_files), read_csv) %>% 
  bind_rows(.id = "file_name")

#cleaning the dataframe
tmax_clean <- tmax_raw %>% 
  fill(`site number`) %>% 
  fill(`site name`) %>% 
  filter(!is.na(date)) %>% 
  select(-"file_name") %>% 
  mutate(month = month(date)) %>% 
  mutate(year = year(date)) %>% 
  clean_names()


# join data
temp_complete <- inner_join(tmax_clean, tmin_clean, by = c("date", "site_name", "site_number", "month", "year")) %>% 
  # only look at temp data from 1950 onwards 
  # there is no temperature data pre 1950 in some stations
  filter(year >= 1950)


# impute missing values
temp_complete_shadow <- bind_shadow(temp_complete)

temp_imp_mean <- temp_complete_shadow %>% 
  mutate(minimum_temperature_deg_c = impute_mean(minimum_temperature_deg_c),
         maximum_temperature_deg_c = impute_mean(maximum_temperature_deg_c)) %>% 
  add_label_shadow()

temp_imp_lm <- temp_complete_shadow %>% 
  as.data.frame() %>% 
  impute_lm(formula = maximum_temperature_deg_c ~ month + year + site_number) %>% 
  impute_lm(formula = minimum_temperature_deg_c ~ month + year + site_number) %>% 
  add_label_shadow()

# spatial data
lang_lon <- read_delim(here::here("data", "acorn_sat_v2_stations.txt"),  delim = ",") %>% 
  clean_names()

lang_lon$lat <- as.numeric(as.character(lang_lon$lat))
lang_lon$long <- as.numeric(as.character(lang_lon$long))

langlong <- revgeo(longitude = lang_lon$long, latitude = lang_lon$lat, output = 'frame', item = 'state')

lang_lon <- lang_lon %>% mutate(state = langlong$state)

lang_lon <- lang_lon %>% 
  mutate(state = replace(state, stnnum %in% c('009999','010916'), 'Western Australia')) %>%
  mutate(state = replace(state, stnnum == '028004', 'Queensland')) %>%
  mutate(state = replace(state, stnnum == '082039', 'Victoria'))

# energy data
states_energy <- read_excel(here::here("data", "australian_energy_statistics_2019_table_c.xlsx"), 
                           sheet = "State summary", 
                           range = "B5:J64") %>% 
  clean_names() %>% 
  rename(year = x1)

states_energy <- states_energy[c(-1),]

states_energy$year <- str_sub(states_energy$year, 1, 4)

au_energy <- read_excel(here::here("data", "australian_energy_statistics_2019_table_c.xlsx"), 
                        sheet = "AUS", 
                        range = "B5:H64") %>% 
  clean_names() %>% 
  rename(year = x1)

au_energy <- au_energy[c(-1),]

au_energy$year <- str_sub(au_energy$year, 1, 4)

# join temp and states
temp_comp_states <- temp_imp_lm %>% left_join(lang_lon, by = c("site_number" = "stnnum"))

temp_imp_lm_year_states <- temp_comp_states %>% group_by(year, site_name, lat, long, state) %>% 
  summarise(year_avg_max = mean(maximum_temperature_deg_c),
            year_avg_min = mean(minimum_temperature_deg_c))

# join temp and energy
temp_year_au <- temp_comp_states %>% 
  group_by(year) %>% summarise(temp_avg_max = mean(maximum_temperature_deg_c),
                               temp_avg_min = mean(minimum_temperature_deg_c))

temp_year_au$year <- as.factor(temp_year_au$year)

au_energy$year <- as.factor(au_energy$year) 

temp_energy_au <- au_energy %>% left_join(temp_year_au, by = "year")

# temperature and states energy
temp_year_states <- temp_comp_states %>% 
  group_by(year, state) %>% 
  summarise(temp_avg_max = mean(maximum_temperature_deg_c),
            temp_avg_min = mean(minimum_temperature_deg_c))

temp_year_states$year <- as.factor(temp_year_states$year)

states_energy_clean <- states_energy %>% select(-australia) %>% 
  pivot_longer(cols = -year, names_to = "state", values_to = "energy_consumption") %>% 
  mutate(state = case_when(
    state == "new_south_wales" ~ "New South Wales",
    state == "victoria" ~ "Victoria",
    state == "queensland" ~ "Queensland",
    state == "western_australia" ~ "Western Australia",
    state == "south_australia" ~ "South Australia",
    state == "tasmania" ~ "Tasmania",
    state == "northern_territory" ~ "Northern Territory",
    TRUE ~ as.character(state)))

states_energy_clean$year <- as.factor(states_energy_clean$year)

temp_energy_states <- states_energy_clean %>% 
  left_join(temp_year_states, by = c("year", "state")) %>% 
  mutate(avg_temp = (temp_avg_max+temp_avg_min)/2)
temp_energy_states$energy_consumption <- as.numeric(as.character(temp_energy_states$energy_consumption))

temp_comp_states_year <- temp_comp_states %>% group_by(year, state) %>% 
  summarise(year_avg_max = mean(maximum_temperature_deg_c),
            year_avg_min = mean(minimum_temperature_deg_c)) %>% 
  pivot_longer(cols = starts_with("year_"), names_to = "category", values_to = "temperature")

# monthly temp and energy (with states)
temp_comp_states_month <- temp_comp_states %>% 
  group_by(month, year, site_name, state) %>% 
  summarise(temp_avg_max = mean(maximum_temperature_deg_c),
            temp_avg_min = mean(minimum_temperature_deg_c)) %>%
  select(year, month, everything())
temp_comp_states_month$year <- as.factor(temp_comp_states_month$year)
temp_energy_month <- states_energy_clean %>%
  left_join(temp_comp_states_month, by = c("year", "state"))
temp_energy_month$energy_consumption <- as.numeric(as.character(temp_energy_month$energy_consumption))

save(temp_imp_lm, file = "data/temp_imp_lm.rda")
save(lang_lon, file = "data/lang_lon.rda")
save(states_energy, file = "data/states_energy.rda")
save(au_energy, file = "data/au_energy.rda")
save(temp_comp_states_year, file = "data/temp_comp_states_year.rda")
save(temp_energy_au, file = "data/temp_energy_au.rda")
save(temp_energy_states, file = "data/temp_energy_states.rda")
save(temp_comp_states, file = "data/temp_comp_states.rda")
save(states_energy_clean, file = "data/states_energy_clean.rda")
save(temp_energy_month, file = "data/temp_energy_month.rda")
save(temp_imp_lm_year_states, file = "data/temp_imp_lm_year_states.rda")