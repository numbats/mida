How to get temperature data:

1. Temperature data can be downloaded from the following link:
ftp://ftp.bom.gov.au/anon/home/ncc/www/change/ACORN_SAT_daily/

2. Download acorn_sat_v2_daily_tmax.tar.gz and acorn_sat_v2_daily_tmin.tar.gz files.

3. Extract the tmax files to "data/tmax", and tmin files to "data/tmin"