#required libraries
#note: please install them if they do not exist
#install.packages('packageName')


library(shiny)  
library(shinydashboard)
library(plotly)
library(ggmap)
library(broom)
library(here)
library(readxl)




#loading the cleaned datasetsand formatting the column names
#for better understanding
inc_vs_mor_df <- read_excel('./data/incidence-mortality.xlsx')
names(inc_vs_mor_df)[2] <- 'Cancer Type'
names(inc_vs_mor_df)[6] <- 'ASR (per 100,000)'

survival_age_df <- read_excel('./data/survival-age.xlsx')
names(survival_age_df)[1] <- 'Cancer Type'
names(survival_age_df)[3] <- 'Age group (years)'
names(survival_age_df)[4] <- 'Survival (%)'

inc_vs_mor_states_df <- read_excel('./data/incidence-mortality-states.xlsx')
names(inc_vs_mor_states_df)[2] <- 'Cancer Type'
names(inc_vs_mor_states_df)[7] <- 'ASR (per 100,000)'



survival_stage_df <- read_excel('./data/survival-stages.xlsx')
names(survival_stage_df)[1] <- 'Cancer Type'
names(survival_stage_df)[4] <- 'Age group (years)'
names(survival_stage_df)[5] <- 'Years after diagnosis'
names(survival_stage_df)[6] <- 'Survival (%)'


mortality_pred_df <- data.frame(read_excel('./data/regression-model.xlsx'))
names(mortality_pred_df)[1] <- 'Cancer Type'
names(mortality_pred_df)[4] <- 'Age group (years)'


#google API Key used to pull the google map
register_google(key="AIzaSyDNZ5SaE2W3mT56f6zvVKs2uLk_PQvfrWA")

#fetching map of melbourne
aus <- get_map("australia",zoom=4,maptype="terrain")




#shiny UI function
ui <- dashboardPage(
  dashboardHeader(title = "Cancer Analysis"),
  #sidebar section
  dashboardSidebar(
    sidebarMenu(
      #sidebar menu items
      menuItem("Overview", tabName = "overview", icon = icon("list-alt")),
      menuItem("Data", tabName = "data", icon = icon("table")),
      menuItem("Incidence and Mortalities", startExpanded = FALSE,
               #sidebar menu subitems
               menuSubItem("User Guide", tabName = "inc-vs-mor-guide"),
               menuSubItem("Dashboard", tabName = "inc-vs-mor")
               ),
      menuItem("Age based Survival Rates", startExpanded = FALSE,
               menuSubItem("User Guide", tabName = "survival-age-guide"),
               menuSubItem("Dashboard", tabName = "survival-age")
               ),
      menuItem("Region-wise Statistics", startExpanded = FALSE,
               menuSubItem("User Guide", tabName = "inc-vs-mor-region-guide"),
               menuSubItem("Dashboard",  tabName = "inc-vs-mor-region")
               ),
      menuItem("Stage based Survival Rates", startExpanded = FALSE,
               menuItem("User Guide", tabName = "survival-stage-guide"),
               menuItem("Dashboard", tabName = "survival-stage")
               ),
      menuItem("Predictive Modelling", tabName = "predictive-modelling",
               badgeLabel = "new", badgeColor = "green"
               )))
  ,
  dashboardBody(
    tabItems(
      #contents of menu item and subitem
      tabItem(tabName = "overview", h3("Overview", style = "font-family:'Cambria';"),
              #row based layout
              #contents of overview
              fluidRow(box(width = 12, solidHeader = TRUE,
                           p("A cancer is an abnormal growth of cells (usually derived from a single abnormal cell). The cells lose their normal control mechanisms and thus are able to multiply continuously, invade nearby tissues, migrate to distant parts of the body, and promote the growth of new blood vessels from which the cells derive nutrients. Cancerous (malignant) cells can develop from any tissue within the body.", style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           p("In 2017, 9.56 million people across the world died of cancer out of a total of 56 million i.e. over 17% contribution to deaths by cancer, making it the second biggest cause of deaths worldwide, after only cardiovascular diseases. (Source for Further Read: https://ourworldindata.org/causes-of-death).", style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           p("Learning as much as we can about this disease is imperative to tackling it. Comprehensive data collection and performing analytics is key to improving cancer outcomes. Improving collection, access, analysis and reporting of national cancer data will help us better understand unwarranted variations in cancer outcomes across the Australian population. (Source for Further Read : https://canceraustralia.gov.au/research-data/cancer-data).", style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           p("The data we will use to perform our analysis on cancer trends in Australia is retrieved from the open data portal of the Australian Institute of Health and Welfare (AIHW). The AIHW is an independent statutory agency that produces authoritative and accessible information and statistics to inform and support better policy and service delivery decisions, leading to better health and wellbeing for all Australians. They have more than 30 years of experience working with health and welfare data. (Source for Further Read : https://www.aihw.gov.au/about-us).", style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           h3("Possible Limitations", style = "font-family:'Cambria';"),
                           br(),
                           p("Even though the dataset is quite comprehensive, understanding cancer or any other disease is a complicated task. In the dataset we have used, there is no mention of any patient medical history or family history, or risk factors such as lifestyle choices (like smoking), or history of residing close to toxic waste sites. All of these parameters usually lead to different type of cancers, so in the future, we could aspire for a dataset that would provide us with these details and help us create a better and more concisely predicting models for cancer development among patients with a certain medical/family history or exposure to specific risk factors.", style = "font-family:'Cambria';font-size:16px")
                           ))),
      tabItem(tabName = "data", h3("Data",style = "font-family:'Cambria';"),
              #contents of data section
              fluidRow(box(width = 12, solidHeader = TRUE,
                           p("Our cancer dataset includes various aspects of the disease including the basic prevalence, incidence and mortality rates, survival percentage, region wise (state) numbers and stage incidence – which means the stage of cancer at which most number of diagnoses are made and the survival numbers of those patients after a specific number of years. This comprehensive capture of data would help us analyse the basic profile of patients that develop a corresponding cancer type. This basic profile of patients would generally include age group and gender.",style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           p("The various aspects of the disease mentioned above can be used to answer many questions surrounding the disease. Our database has information captured to answer specific questions and some have different values of the same parameter set. In some we observe that data has been captured from 1982, while in others the capture has been from 2010 or 2015. Age differentiation of patients is done in most cases, whereas gender differentiation is done in all. Age groups are maintained in the same range throughout the document.",style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           p("Following are the research questions we look to answer from this dataset:",style = "font-family:'Cambria';font-size:16px;"),
                           p("1. What are the incidence and mortality rates of all types of cancers?",style = "font-family:'Cambria';font-size:16px;"),
                           p("2. Based on age, what is the survival rate of different types of cancers?",style = "font-family:'Cambria';font-size:16px;"),
                           p("3. Which states in Australia have seen a change in cancer trends since 1982?",style = "font-family:'Cambria';font-size:16px;"),
                           p("4. What is the survival rate of patients diagnosed at a specific stage of the disease?",style = "font-family:'Cambria';font-size:16px;"),
                           p("5.	What does a simple linear regression model to predict cancer mortality cases look like?",style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           p("Our platform will let the user enter the desired inputs which could be cancer type, gender or indicator (incidence or mortality rate). Our analysis pages are split into two identical sections to help the user compare the plots generated by their input parameters.", style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           p("For example, when we compare the incidence rates of lung cancer between both sexes by plotting for males and females on each side, we can clearly observe that the incidence rate change has been opposite for sexes since 1982, with a drop in males and an increase in females.",style = "font-family:'Cambria';font-size:16px;"),
                           br(),
                           h3("Tidying the data", style = "font-family:'Cambria';"),
                           br(),
                           p("•	As mentioned, our dataset was downloaded from the AIHW portal for cancer research (Source : https://www.aihw.gov.au/reports-data/health-conditions-disability-deaths/cancer/data) in xlsx form.",style = "font-family:'Cambria';font-size:16px;"),
                           p("•	Using read_xlsx, read different sheets of the document as needed for future use.",style = "font-family:'Cambria';font-size:16px;"),
                           p("•	Sliced the rows needed in the dataset using slice.",style = "font-family:'Cambria';font-size:16px;"),
                           p("• Selected the required columns from the dataset using select.",style = "font-family:'Cambria';font-size:16px;"),
                           p("•	Used !is.na to remove NA values from all columns.",style = "font-family:'Cambria';font-size:16px;"),
                           p("•	Removed “Total” rows, that initially had sub-total values for certain age groups, genders and cancer types.",style = "font-family:'Cambria';font-size:16px;"),
                           p("•	Removed records containing unwanted strings like “Notes”, “n.p.”, “. .”.",style = "font-family:'Cambria';font-size:16px;"),
                           p("•	While tidying regional data, removed “Australia” records for column “State” and added latitude and longitude values for all states.", style = "font-family:'Cambria';font-size:16px;")
                           ))),
      tabItem(tabName="inc-vs-mor-guide", h3("Guidelines to use the Dashboard", style = "font-family:'Cambria';"),
              #contents of incidence vs mortality user guide 
              fluidRow(column(width = 12,
                              box(width = NULL, solidHeader = TRUE,
                                  h4("Incidence and Mortalities", style = "font-family:'Cambria';font-weight:bold;"),
                                  p("This section focuses on the incidence and the mortality metrics (such as counts, age standardized ratio, etc.) of different cancers over the years, 1982-2020. The layout is designed in such a way that it would help you to compare the trends across different cancers and genders.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("The questions which are addressed through this section are as follows.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("1. Are Incidences/Mortalities in a particular type of Cancer (say Liver Cancer) decreasing/increasing over time across different Genders?", style = "font-family:'Cambria';font-size:16px;"),
                                  p("2. Which type of Cancer has the highest/lowest Incidence or Mortality Cases across different Genders?", style = "font-family:'Cambria';font-size:16px"),
                                  br(),
                                  p("To answer the first question (say), you will have to do the following.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("1. Select Incidence/Mortality in both the Indicator Dropdowns.", style = "font-family: 'Cambria';font-size:16px;"),
                                  p("2. Select Males in radio button of the left side.", style = "font-family: 'Cambria';font-size:16px;"),
                                  p("3. Select Females in the radio button of the right side.", style = "font-family: 'Cambria';font-size:16px;"),
                                  p("4. Select Liver Cancer in both the Cancer Type dropdowns.", style = "font-family: 'Cambria';font-size:16px;"),
                                  br(),
                                  p("Below are some screenshots about how to use the dashboard for your reference.", style = "font-family:'Cambria';font-size:16px;"),
                                  img(src = "page1.png", height = "500px", width = "100%"),
                                  img(src = "page2.png", height = "500px", width = "100%"),
                                  p("These plots represent the incidence (left) and mortality (right) rate of breast cancer in Australia since 1982. We can see that the incidence rate has been increasing with time and has been linearly increasing since around 2015. On the other hand, the mortality rate has been decreasing, as more awareness has been spread recently of this particular type of cancer, leading to earlier diagnosis and treatment.", style = "font-family:'Cambria';font-size:16px;font-weight:bold;")
                                  ))
                       
                       )
              ),
      tabItem(tabName = "inc-vs-mor", h3("Explore and Compare the Incidence/Mortality Metrics of different Cancers over the years, 1982-2020", style = "font-family:'Cambria';"),
              br(),
              #row-column layout
              #contents of incidence vs mortality dashboard
              fluidRow(column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  #dropdown to select the Indicator
                                  selectInput("source1", h4("Select the Indicator", style = "font-family:'Cambria';font-weight:bold;"), choices = unique(inc_vs_mor_df$Source))
                              )),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("source2", h4("Select the Indicator", style = "font-family:'Cambria';font-weight:bold;"), choices = unique(inc_vs_mor_df$Source))
                              )),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  #radiobutton to select the Gender
                                  radioButtons("gender1", h4("Select the Gender", style = "font-family:'Cambria';font-weight:bold"), choices = unique(inc_vs_mor_df$Sex), selected = unique(inc_vs_mor_df$Sex)[2]),
                                  p("Note: In our data, Persons refer to those who have chosen to not specify their Gender", style = "font-family:'Cambria';font-size:16px;font-weight:bold")
                              )),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  radioButtons("gender2", h4("Select the Gender", style = "font-family:'Cambria';font-weight:bold"), choices = unique(inc_vs_mor_df$Sex)),
                                  p("Note: In our data, Persons refer to those who have chosen to not specify their Gender", style = "font-family:'Cambria';font-size:16px;font-weight:bold")
                              )),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  #dropdown to select the cancer type
                                  selectInput("cancertype1", h4("Select the Cancer Type", style= "font-family:'Cambria';font-weight:bold"), choices = unique(inc_vs_mor_df$`Cancer Type`))
                                  )),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("cancertype2", h4("Select the Cancer Type", style= "font-family:'Cambria';font-weight:bold"), choices = unique(inc_vs_mor_df$`Cancer Type`))
                              ))),
              
              fluidRow(
                      column(width = 6,
                             box(width = NULL, solidHeader = TRUE,
                                 h4(textOutput("title3"), style= "font-family:'Cambria';font-weight:bold"),
                                 #plot rendered from server function
                                 plotlyOutput("plot3"))),
                      column(width = 6,
                             box(width = NULL, solidHeader = TRUE,
                                 h4(textOutput("title4"), style= "font-family:'Cambria';font-weight:bold"),
                                 plotlyOutput("plot4")))),
             fluidRow(
                      column(width = 6,
                              box(width = NULL,  solidHeader = TRUE,
                              h4(textOutput("title1"), style= "font-family:'Cambria';font-weight:bold"),
                              plotlyOutput("plot1"))),
                       column(width = 6,
                              box(width = NULL,  solidHeader = TRUE,
                                  h4(textOutput("title2"), style= "font-family:'Cambria';font-weight:bold"),
                                  plotlyOutput("plot2"))))
              ),
      tabItem(tabName="survival-age-guide", h3("Guidelines to use the Dashboard", style = "font-family:'Cambria';"),
              #age based survival rate user guide
              fluidRow(column(width = 12,
                              box(width = NULL, solidHeader = TRUE,
                                  h4("Age based Survival Rates", style = "font-family:'Cambria';font-weight:bold;"),
                                  p("This section focuses on the survival rates of different cancers across age groups. The layout is designed in such a way that it would help you to compare the trends across different cancers and genders.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("The main question which is addressed through this section is given below.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("1. What is the change seen in the survival rate of a particular type of Cancer (say Lip Cancer) across different Age groups and Genders?", style = "font-family:'Cambria';font-size:16px;"),
                                  p("To answer the above question (say), you will have to do the following.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("1. Select Lip Cancer in both the Cancer Type Dropdowns.", style = "font-family: 'Cambria';font-size:16px;"),
                                  p("2. Select Females in radio button of the left side.", style = "font-family: 'Cambria';font-size:16px;"),
                                  p("3. Select Males in the radio button of the right side.", style = "font-family: 'Cambria';font-size:16px;"),
                                  br(),
                                  p("Below are some screenshots about how to use the dashboard for your reference.", style = "font-family:'Cambria';font-size:16px;"),
                                  img(src = "page3.png", height = "500px", width = "100%"),
                                  img(src = "page4.png", height = "500px", width = "100%"),
                                  p("These plots represent the survival percentage of lip cancer patients in different age groups in Australia. Females (left) and males (right) are compared with each other, and as we can see, the highest survival percentage is that of 40-44-year-old patients for females and 30-34-year-old patients for males. Lowest surviving age group is 75+ for both genders. One would expect the graph to drop linearly with rising age groups, but the graph is not linear, and only steadily drops when the 70-year-old age group is reached.", style = "font-family:'Cambria';font-size:16px;font-weight:bold;")
                              ))
                       
              )
      ),
      tabItem(tabName = "survival-age", h3("Explore and Compare Survival Rates of Cancers across different Age groups", style = "font-family:'Cambria';"),
              br(),
              #age based survival rate contents
              fluidRow(column(width = 6,
                             box(width = NULL, solidHeader = TRUE,
                                 selectInput("cancertype3", h4("Select the Cancer Type", style= "font-family:'Cambria';font-weight:bold"), choices = unique(survival_age_df$`Cancer Type`))
                              )),
                      column(width = 6,
                             box(width = NULL, solidHeader = TRUE,
                                 selectInput("cancertype4", h4("Select the Cancer Type", style = "font-family:'Cambria';font-weight:bold;"), choices = unique(survival_age_df$`Cancer Type`))
                             )),
                      column(width = 6,
                             box(width = NULL, solidHeader = TRUE,
                                 selectInput("gender3", h4("Select the Gender", style = "font-family:'Cambria';font-weight:bold;"), choices = unique(survival_age_df$Sex), selected = unique(survival_age_df$Sex)[2]),
                                 p("Note: In our data, Persons refer to those who have chosen to not specify their Gender", style = "font-family:'Cambria';font-size:16px;font-weight:bold")
                             )),
                      column(width = 6,
                             box(width = NULL, solidHeader = TRUE,
                                 selectInput("gender4", h4("Select the Gender", style = "font-family:'Cambria';font-weight:bold;"), choices = unique(survival_age_df$Sex)),
                                 p("Note: In our data, Persons refer to those who have chosen to not specify their Gender", style = "font-family:'Cambria';font-size:16px;font-weight:bold")
                             ))),
              fluidRow(
                column(width = 6,
                       box(width = NULL, solidHeader = TRUE,
                           h4(textOutput("title5"), style= "font-family:'Cambria';font-weight:bold"),
                           plotlyOutput("plot5"))),
                column(width = 6,
                       box(width = NULL, solidHeader = TRUE,
                           h4(textOutput("title6"), style= "font-family:'Cambria';font-weight:bold"),
                           plotlyOutput("plot6"))))
              ),
      
      tabItem(tabName="inc-vs-mor-region-guide", h3("Guidelines to use the Dashboard", style = "font-family:'Cambria';"),
              #region wise statistics user guide
              fluidRow(column(width = 12,
                              box(width = NULL, solidHeader = TRUE,
                                  h4("Region-wise Statistics", style = "font-family:'Cambria';font-weight:bold;"),
                                  p("This section focuses on the region wise incidence/mortality metrics of different cancers over the years, 1982-2015.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("The questions which are addressed through this section are as follows:", style = "font-family:'Cambria';font-size:16px;"),
                                  p("1. What is the region-wise incidence/mortality cases in a particular type of cancer (say Lung Cancer) across different years?", style = "font-family:'Cambria';font-size:16px;"),
                                  p("2. Are the cancer cases (say Lip Cancer) increasing/decreasing over the years across different states and genders?", style = "font-family:'Cambria';font-size:16px;"),
                                  p("To answer the first question (say), you will have to do the following.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("1. Select Lung Cancer in the Cancer Type Dropdown.", style = "font-family: 'Cambria';font-size:16px;"),
                                  p("2. Select Incidence/Mortality in the Indicator Dropdown.", style = "font-family: 'Cambria';font-size:16px;"),
                                  p("3. Select 2014 in the Year Dropdown.", style = "font-family: 'Cambria';font-size:16px;"),
                                  br(),
                                  p("Below are some screenshots about how to use the dashboard for your reference.", style = "font-family:'Cambria';font-size:16px;"),
                                  img(src = "page5.png", height = "500px", width = "100%"),
                                  img(src = "page6.png", height = "500px", width = "100%"),
                                  p("The above plots represent region wise lung cancer mortality in Australia. NSW has the highest number of cases, followed by Victoria and Queensland, which could be owing to the higher population in the states. ACT and Northern Territory have very small numbers. It seems to be a male dominated disease in all regions.",style = "font-family:'Cambria';font-size:16px;font-weight:bold")
                              ))
                       
              )
      ),
      tabItem(tabName = "inc-vs-mor-region", h3("Explore the Region-wise Incidence/Mortality Metrics of diferent Cancers over the years, 1982-2015", style = "font-family:'Cambria';"),
              br(),
              #region wise statistics contents
              fluidRow(column(width = 4,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("cancertype5", h4("Select the Cancer Type", style = "font-family:'Cambria';font-weight:bold"), choices = unique(inc_vs_mor_states_df$`Cancer Type`))
                              )),
                       column(width = 4,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("source3", h4("Select the Indicator", style = "font-family:'Cambria';font-weight:bold;"), choices = unique(inc_vs_mor_states_df$Source))
                              )),
                       column(width = 4,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("year1", h4("Select the Year", style = "font-family:'Cambria';font-weight:bold;"), choices = unique(inc_vs_mor_states_df$Year))
                              ))),
              
              fluidRow(
                column(width = 6,
                       box(width = NULL, solidHeader = TRUE,
                           h4(textOutput("title7"), style= "font-family:'Cambria';font-weight:bold"),
                           plotlyOutput("plot7", height = "100%", width="100%")
                           )),
                column(width = 6,
                       box(width = NULL, solidHeader = TRUE,
                           h4(textOutput("title8"), style= "font-family:'Cambria';font-weight:bold"),
                           br(),br(),
                           plotlyOutput("plot8")
                       ))),
              h3("Explore the Time Series trends of different Cancers across different States and Genders over the years, 1982-2015", style = "font-family:'Cambria';"),
              br(),
              fluidRow(column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("cancertype6", h4("Select the Cancer Type", style = "font-family:'Cambria';font-weight:bold"), choices = unique(inc_vs_mor_states_df$`Cancer Type`))
                              )),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("state1", h4("Select the state", style = "font-family:'Cambria';font-weight:bold;"), choices = unique(inc_vs_mor_states_df$State))
                              ))),
              fluidRow(
                column(width = 12,
                       box(width = NULL, solidHeader = TRUE,
                           h4(textOutput("title9"), style= "font-family:'Cambria';font-weight:bold"),
                           plotlyOutput("plot9")
                       )))
              ),
      tabItem(tabName="survival-stage-guide", h3("Guidelines to use the Dashboard", style = "font-family:'Cambria';"),
              #survival stage user guide 
              fluidRow(column(width = 12,
                              box(width = NULL, solidHeader = TRUE,
                                  h4("Stage based Survival Rates", style = "font-family:'Cambria';font-weight:bold;"),
                                  p("This section focuses on the survival rates of different cancers across different stages and genders.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("The questions which are addressed through this section are as follows:", style = "font-family:'Cambria';font-size:16px;"),
                                  p("1. What is the stage at which the survival rate is high/low in a particular type of cancer (say Breast Cancer) across different genders?", style = "font-family:'Cambria';font-size:16px;"),
                                  p("2. Does the chances of survival increase/decrease in earlier/later stages of Cancer?", style = "font-family:'Cambria';font-size:16px;"),
                                  p("To answer the first question (say), you will have to do the following.", style = "font-family:'Cambria';font-size:16px;"),
                                  p("1. Select Breast Cancer in Cancer Type Dropdown of the left side.", style = "font-family: 'Cambria';font-size:16px;"),
                                  p("2. Select Colorectal Cancer in Cancer Type Dropdown of the right side.", style = "font-family: 'Cambria';font-size:16px;"),
                                  br(),
                                  p("Below are some screenshots about how to use the dashboard for your reference.", style = "font-family:'Cambria';font-size:16px;"),
                                  img(src = "page7.png", height = "500px", width = "100%"),
                                  p("Stage based survival rates give us an idea about how high or low the survival rate of a patient is, when diagnosed at a specific stage.
In the above plots, we have analysed breast cancer (left) and colorectal cancer (right). In both cases, as would be the case with most cancers if not all, earlier the diagnosis, better the chances of survival. For colorectal cancer, the survival percentage is trending similarly for all genders, except females who have a slightly higher survival percentage than other genders even at the last stage of diagnosis.",style = "font-family:'Cambria';font-size:16px;font-weight:bold")
                              ))
                       
              )
      ),
      tabItem(tabName = "survival-stage", h3("Explore and Compare the Survival Rates of Cancers at different Stages across various genders", style = "font-family:'Cambria';"),
              br(),
              #survival stage contents
              fluidRow(column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("cancertype7", h4("Select the Cancer Type", style = "font-family:'Cambria';font-weight:bold"), choices = unique(survival_stage_df$`Cancer Type`), selected = unique(survival_stage_df$`Cancer Type`)[1])
                              )),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("cancertype8", h4("Select the Cancer Type", style = "font-family:'Cambria';font-weight:bold"), choices = unique(survival_stage_df$`Cancer Type`), selected = unique(survival_stage_df$`Cancer Type`)[2])
                              ))),
              fluidRow(column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  h4(textOutput("title10"), style = "font-family:'Cambria';font-weight:bold"),
                                  plotlyOutput("plot10"))),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  h4(textOutput("title11"), style = "font-family:'Cambria';font-weight:bold"),
                                  plotlyOutput("plot11")))),
              fluidRow(column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  h4(textOutput("title12"), style = "font-family:'Cambria';font-weight:bold"),
                                  plotlyOutput("plot12"))),
                       column(width = 6,
                              box(width = NULL, solidHeader = TRUE,
                                  h4(textOutput("title13"), style = "font-family:'Cambria';font-weight:bold"),
                                  plotlyOutput("plot13"))))
              ),
      tabItem(tabName = "predictive-modelling",
              #predictive modelling contents
              fluidRow(column(width = 12, h3("Simple Linear Regression Model to predict Cancer Mortality Cases", style = "font-family:Cambria;"),
                              box(width = NULL, solidHeader = TRUE,
                                  selectInput("independent1", h4("Select the Feature/Independent Variable to build the Model", style = "font-family:'Cambria';font-weight:bold"), choices = names(mortality_pred_df[c(1:4)]))
                                ))),
              fluidRow(column(width = 12,
                              box(width = NULL, solidHeader = TRUE,
                                  h4("The target/dependent Variable that the model would be predicting is Number of Mortality Cases.", style = "font-family:'Cambria'"),
                                  br(),
                                  h4("Below is an overview of the Model", style = "font-family:'Cambria';"),
                                  br(),
                                  h5("Note : Only top 6 records are displayed under Model Predictions Panel for faster loading. Also, the model visualization may take some time to load due to large number of data points.", style = "font-family:'Cambria';font-weight:bold"),
                                  br(),
                                  h5("Disclaimer : Predicting Cancer depends on many factors. This is just a demonstration of a simple machine learning model that is able to predict considering 1 factor at a time.", style = "font-family:'Cambria';font-weight:bold;"),
                                  br(),
                                  tabsetPanel(type = "tab",
                                              tabPanel("Model Summary", verbatimTextOutput("summary1")),
                                              tabPanel("Model Assessments", verbatimTextOutput("assess1")),
                                              tabPanel("Model Predictions", tableOutput("table1")),
                                              tabPanel("Visualizing results", plotlyOutput("plot14"))),
                                  br(),
                                  uiOutput("rsq1")
                              )))
              )
    )
  )
)


#shiny server function
server <- function(input, output) {

  output$title1 <- renderText(paste("Cancer Distribution as per",input$gender1))
  output$plot1 <- renderPlotly({
    inc_vs_mor_df_filtered <- inc_vs_mor_df%>%
                              filter(Source== input$source1 & Sex==input$gender1)%>%
                              group_by(`Cancer Type`)%>%
                              summarise(Total = sum(Count))

    plt1 <- ggplot(data = inc_vs_mor_df_filtered, mapping = aes(x = `Cancer Type`, y = Total)) + geom_bar(stat = "identity", fill = "steelblue") +
      labs(x = 'Cancer Type', y = 'Cases')+
      theme(text=element_text(size=12,  family="Comic Sans MS"), axis.text.x = element_text(angle = 90)) + scale_y_continuous(labels = function(y) format(y, scientific = FALSE))
    
    tryCatch(ggplotly(plt1))
  })
  
  output$title2 <- renderText(paste("Cancer Distribution as per",input$gender2))
  output$plot2 <- renderPlotly({
    inc_vs_mor_df_filtered <- inc_vs_mor_df%>%
      filter(Source== input$source2 & Sex==input$gender2)%>%
      group_by(`Cancer Type`)%>%
      summarise(Total = sum(Count))
    
    plt2 <- ggplot(data = inc_vs_mor_df_filtered, mapping = aes(x = `Cancer Type`, y = Total)) + geom_bar(stat = "identity", fill = "red") +
      labs(x = 'Cancer Type', y = 'Cases')+
      theme(text=element_text(size=12,  family="Comic Sans MS"), axis.text.x = element_text(angle = 90)) + scale_y_continuous(labels = function(y) format(y, scientific = FALSE))
    
    tryCatch(ggplotly(plt2))
  })
  
  output$title3 <- renderText(paste(input$cancertype1, input$source1, "Trends in", input$gender1,"over the years 1982-2020"))
  output$plot3 <- renderPlotly({
    inc_vs_mor_df_filtered <- inc_vs_mor_df%>%
                              filter(Source==input$source1 & Sex==input$gender1 & `Cancer Type`==input$cancertype1)

    plt3 <- ggplot(data = inc_vs_mor_df_filtered, mapping = aes(x = Year, y = `ASR (per 100,000)`)) + geom_line(color = "steelblue") + geom_point()
      labs(x = 'Year', y = 'ASR (per 100,000)')+
      theme(text=element_text(size=12,  family="Comic Sans MS"))
    
      tryCatch(ggplotly(plt3))
  })
  
  output$title4 <- renderText(paste(input$cancertype2, input$source2, "Trends in", input$gender2,"over the years 1982-2020"))
  output$plot4 <- renderPlotly({
    inc_vs_mor_df_filtered <- inc_vs_mor_df%>%
      filter(Source==input$source2 & Sex==input$gender2 & `Cancer Type`==input$cancertype2)
    
    plt4 <- ggplot(data = inc_vs_mor_df_filtered, mapping = aes(x = Year, y = `ASR (per 100,000)`)) + geom_line(color = "red") + geom_point()
    labs(x = 'Year', y = 'ASR (per 100,000)')+
      theme(text=element_text(size=12,  family="Comic Sans MS"))
    
    tryCatch(ggplotly(plt4))
  })
  
  output$title5 <- renderText(paste(input$cancertype3, "Trends in", input$gender3,"across age groups"))
  output$plot5 <- renderPlotly({
    survival_age_df_filtered <- survival_age_df%>%
      filter(Sex==input$gender3 & `Cancer Type`==input$cancertype3)
    
    
    
    plt5 <- ggplot(data = survival_age_df_filtered, mapping = aes(x = `Age group (years)`, y = `Survival (%)`)) + geom_point(size = 5, color = "tomato") +
      geom_segment(aes(x = `Age group (years)`,
                       xend = `Age group (years)`,
                       y = 0,
                       yend = `Survival (%)`), color = "tomato") +
      labs(x = 'Age groups', y = 'Survival Percentage')+
      theme(text=element_text(size=12,  family="Comic Sans MS"), axis.text.x = element_text(angle=65, vjust=0.6))
    
    tryCatch(ggplotly(plt5))
  })
  
  output$title6 <- renderText(paste(input$cancertype4, "Trends in", input$gender4,"across age groups"))
  output$plot6 <- renderPlotly({
    survival_age_df_filtered <- survival_age_df%>%
      filter(Sex==input$gender4 & `Cancer Type`==input$cancertype4)
    
    
    plt6 <- ggplot(data = survival_age_df_filtered, mapping = aes(x = `Age group (years)`, y = `Survival (%)`)) + geom_point(size = 5, color = "#00ba38") +
      geom_segment(aes(x = `Age group (years)`,
                       xend = `Age group (years)`,
                       y = 0,
                       yend = `Survival (%)`), color = "#00ba38") +
      labs(x = 'Age groups', y = 'Survival Percentage')+
      theme(text=element_text(size=12,  family="Comic Sans MS"), axis.text.x = element_text(angle=65, vjust=0.6))
    
    tryCatch(ggplotly(plt6))
  })
  
  output$title7 <- renderText(paste(input$cancertype5, input$source3, "Cases in the year", input$year1,"across different states"))
  
  output$plot7 <- renderPlotly({
    inc_vs_mor_states_df_filtered <- inc_vs_mor_states_df%>%
      filter(`Cancer Type`==input$cancertype5, Source==input$source3, Year==input$year1)%>%
      group_by(State, Latitude, Longitude)%>%
      summarise(Total = sum(Count))
    
    
    
    plt7 <- ggmap(aus) +
       geom_point(data = inc_vs_mor_states_df_filtered, aes(x = Longitude, y = Latitude, color = Total, size = Total))
  
    tryCatch(ggplotly(plt7))
    
  })
  
  output$title8 <- renderText(paste("Region-wise",input$cancertype5, input$source3, "Cases in the year", input$year1,"across different genders"))
  
  output$plot8 <- renderPlotly({
    inc_vs_mor_states_df_filtered <- inc_vs_mor_states_df%>%
      filter(`Cancer Type`==input$cancertype5, Source==input$source3, Year==input$year1)%>%
      group_by(State, Sex)%>%
      summarise(Average = mean(Count))
    
    plt8 <- ggplot(data = inc_vs_mor_states_df_filtered, mapping = aes(x = State, y = Average, fill = Sex)) + geom_bar(stat = "identity", position=position_dodge()) +
      labs(x = 'State', y = 'Cases')+
      theme(text=element_text(size=12,  family="Comic Sans MS"), axis.text.x = element_text(angle = 45)) + scale_y_continuous(labels = function(y) format(y, scientific = FALSE))
    
    tryCatch(ggplotly(plt8))
  })
  
  output$title9 <- renderText(paste("Time Series Analysis of",input$cancertype5,"in", input$state1, "across different genders over the years, 1982-2015"))
  
  output$plot9 <- renderPlotly({
    inc_vs_mor_states_df_filtered <- inc_vs_mor_states_df %>%
      filter(`Cancer Type`==input$cancertype6, State==input$state1)%>%
      group_by(Year,Sex)%>%
      summarise(Average = mean(Count))
    
    plt9 <- ggplot(data = inc_vs_mor_states_df_filtered, mapping = aes(x = Year, y = Average)) + geom_line(aes(color = Sex)) + geom_point(aes(color = Sex))+
    labs(x = 'Year', y = 'Cases')+
      theme(text=element_text(size=12,  family="Comic Sans MS"))
    
    tryCatch(ggplotly(plt9))
  })
  
  
  output$title10 <-  renderText(paste(input$cancertype7, "Survival Rates across various stages as per Gender"))
  
  output$plot10 <- renderPlotly({
    survival_stage_df_filtered <- survival_stage_df %>%
      filter(`Cancer Type`==input$cancertype7)%>%
      group_by(Diagnosis_stage, Sex) %>%
      summarise(Average = mean(`Survival (%)`))
    
    plt10 <- ggplot(data = survival_stage_df_filtered, mapping = aes(x = Diagnosis_stage, y = Average, fill = Sex)) +
      geom_bar(stat="identity", position = position_dodge()) + 
      labs(x = 'Stages', y = 'Survival (%)') + 
      theme(text=element_text(size=12,  family="Comic Sans MS"))
    
    tryCatch(ggplotly(plt10))
    
  })
  
  output$title11 <-  renderText(paste(input$cancertype8, "Survival Rates across various stages as per Gender"))
  
  output$plot11 <- renderPlotly({
    survival_stage_df_filtered <- survival_stage_df %>%
      filter(`Cancer Type`==input$cancertype8)%>%
      group_by(Diagnosis_stage, Sex) %>%
      summarise(Average = mean(`Survival (%)`))
    
    plt11 <- ggplot(data = survival_stage_df_filtered, mapping = aes(x = Diagnosis_stage, y = Average, fill = Sex)) +
      geom_bar(stat="identity", position = position_dodge()) + 
      labs(x = 'Stages', y = 'Survival (%)') + 
      theme(text=element_text(size=12,  family="Comic Sans MS"))
    
    tryCatch(ggplotly(plt11))
    
  })
  

  
  output$title12 <-  renderText(paste(input$cancertype7, "Diagnosis Trend across various stages"))
  
  output$plot12 <- renderPlotly({
    survival_stage_df_filtered <- survival_stage_df %>%
      filter(`Cancer Type`==input$cancertype7)
    
    plt12 <- ggplot(survival_stage_df_filtered, mapping = aes(x = Diagnosis_stage, y= `Survival (%)`, color = `Years after diagnosis`)) +
      geom_point() +labs(x = 'Stages', y = 'Survival (%)') + 
      theme(text=element_text(size=12,  family="Comic Sans MS"))
    
    tryCatch(ggplotly(plt12))
  })
  
  
  output$title13 <-  renderText(paste(input$cancertype8, "Diagnosis Trend across various stages"))
  
  output$plot13 <- renderPlotly({
    survival_stage_df_filtered <- survival_stage_df %>%
      filter(`Cancer Type`==input$cancertype8)
    
    plt13 <- ggplot(survival_stage_df_filtered, mapping = aes(x = Diagnosis_stage, y= `Survival (%)`, color = `Years after diagnosis`)) +
      geom_point() +labs(x = 'Stages', y = 'Survival (%)') + 
      theme(text=element_text(size=12,  family="Comic Sans MS"))
    
    tryCatch(ggplotly(plt13))
    
  })
  
  output$summary1 <- renderPrint({
    model1 <- lm(mortality_pred_df[,5]~mortality_pred_df[,input$independent1], data = mortality_pred_df)
    summary(model1)
  })
  
  output$assess1 <- renderPrint({
    model1 <- lm(mortality_pred_df[,5]~mortality_pred_df[,input$independent1], data = mortality_pred_df)
    glance(model1)
  })
  
  output$table1 <- renderTable({
    model1 <- lm(mortality_pred_df[,5]~mortality_pred_df[,input$independent1], data = mortality_pred_df)
    pred <- predict(model1, newdata = mortality_pred_df)
    df <- data.frame(mortality_pred_df$Count, pred)
    names(df) <- c("Actual", "Predicted")
    head(df,1000)
  })
  
  #server logic to calculate the rsquared metric
  output$rsq1 <- renderUI({
    model1 <- lm(mortality_pred_df[,5]~mortality_pred_df[,input$independent1], data = mortality_pred_df)
    
    #determining the rsquared
    r2 <- glance(model1)$r.squared
    est <- tidy(model1)$estimate
    HTML("This linear model produces an equation which expresses Count/No of Mortality Cases as a function of", input$independent1,"<br><b>i.e. Count = ",
         input$independent1, "*", round(est[2],2), "+",round(est[1],2),"</b><br> Further,",round(r2*100,2),"% of the variation in Count is explained by", input$independent1)
    })
  
  output$plot14 <- renderPlotly({
    model1 <- lm(mortality_pred_df[,5]~mortality_pred_df[,input$independent1], data = mortality_pred_df)
    pred <- predict(model1, newdata = mortality_pred_df)
    df <- data.frame(mortality_pred_df$Count, pred)
    names(df) <- c("Actual", "Predicted")
    plt14 <- ggplot(df, mapping = aes(x = Actual, y = Predicted)) + geom_point() + theme(text=element_text(size=12,  family="Comic Sans MS"))
    tryCatch(ggplotly(plt14))
  })
  
}

shinyApp(ui, server)